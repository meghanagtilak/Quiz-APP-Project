const quizData=[{question:"What is the capital of France?",
    options:["Paris","London","Berlin","Madrid"],
    answer:"Paris"},
    {question:"Which planet is known as the red planet?",
    options:["Earth","Mars","Jupiter","Venus"],
    answer:"Mars"},
    {question:"What is 2+2?",
     options:["3","4","5","6"],
     answer:"4"},
     {question:"What is Squre Root Of 25?",
        options:["10","5","9","11"],
        answer:"5"}];
    
export default quizData;