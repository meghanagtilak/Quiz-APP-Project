import React from "react";
import { useState } from "react";
import quizData from "../data/quizData";
import {useNavigate}  from "react-router-dom";
import "./componant.css";

const Quiz =()=> {const[currentQuestion,setCurrentQuestion]=useState(0);
    const[score,setScore]=useState(0);
    const[selectedOption,setSelectedOption]=useState("");
    const[answers,setAnswers]=useState([]);
    const navigate=useNavigate();

    const handleAnswer=()=>
    {const Correct=selectedOption===quizData[currentQuestion].answer;
        if(Correct)setScore(score+1);

        setAnswers([...answers,{question:quizData[currentQuestion].question,
            Selected:selectedOption,
            correctAnswer:quizData[currentQuestion].answer}]);

            const next=currentQuestion+1;
            if (next<quizData.length) {
                setCurrentQuestion(next);
                setSelectedOption("");
            } else {
                const scores=JSON.parse(localStorage.getItem("scores"))||[];
                scores.push({score:Correct?score+1:score,total:quizData.length});
                localStorage.setItem("scores",JSON.stringify(scores));
                navigate("/result",{state:{score:Correct?score+1:score,
                    total:quizData.length,
                    answers:[...answers,{question:quizData[currentQuestion].question,
                        Selected:selectedOption,
                        correctAnswer:quizData[currentQuestion].answer
                    }]
                }
                });
            }
        }

return(<div className="Container">
    <h2 className="id3">{quizData[currentQuestion].question}</h2>
    <div className="list-group my-3">
    {quizData[currentQuestion].options.map((option,idx)=>(<label key={idx} className="list-group-item">
    <input type="radio" name="option" value={option} checked={selectedOption===option} onChange={(e)=>setSelectedOption(e.target.value)} className="from-check-input-me-1"/> {option} </label>)) }
    </div>
    <div className="d-flex justfy-content-between">
    <div className="id4">Score:{score}</div><button className="btn btn-success" onClick={handleAnswer} disabled={!selectedOption}>Next</button></div></div>);
};

export default Quiz;

