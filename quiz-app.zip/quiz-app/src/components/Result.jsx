import React from "react";
import{Link,useLocation}from "react-router-dom";
import "./componant.css";

const Result=()=>{const location=useLocation();
    const{score,total,answers}=location.state||{score:0,total:0,answer:[]};

    return(<div className="Container">
        <h2 className="text-center">Your Score:{score}/{total}</h2>
        <h4 className="id4">Review Answers:</h4>
        <ul className="list-group">
        {answers.map((entry,index)=>(<li key={index} className="list-group-item">
         <strong>Q{index+1}:</strong>{entry.question}<br/> 
         <span className={entry.selected===entry.correctAnswer? "text-success":"text-danger"}>
            Your Answer:{entry.selected}</span><br/>
          <span className="text-primary">Correct Answer:{entry.correctAnswer}</span></li>))}</ul>
          <div className="text-center mt-4">
            <Link to="/" className="btn">Back to Home</Link></div></div>);};
    
export default Result;