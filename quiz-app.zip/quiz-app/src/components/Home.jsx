import React from "react";
import {Link} from "react-router-dom";
import quizData from "../data/quizData";
import "./componant.css";


const Home=()=>{const scores=JSON.parse(localStorage.getItem("scores")) || [];

    return(<div className="Container">
        <h1 className="id1">Quiz App</h1>
        <Link to="/quiz" className="btn">Start Quiz</Link>
         <h3 className="id2">Previous Scores:</h3>
         <ul className="list-group">
            {scores.length===0 && 
            <li className="list-group-item">No Scores yet</li>}
            {scores.map((entry,index)=>(
                <li key={index}className="list-group-item">Score Obtained in Attempt {index+1} &nbsp;: 
                 &nbsp;&nbsp;{entry.score} / {entry.total} &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                 Percentage : {Math.round(entry.score/entry.total*100)}
                </li>))}</ul></div>);};

        export default Home;